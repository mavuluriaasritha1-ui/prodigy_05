<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Function to highlight hashtags
function highlightHashtags($text) {
    return preg_replace('/#(\w+)/', '<span style="color: blue;">#$1</span>', $text);
}

// Fetch Top 3 Trending Posts (Most Liked Posts)
$trending_result = mysqli_query($conn, "
    SELECT posts.*, users.name, users.profile_picture,
    (SELECT COUNT(*) FROM likes WHERE likes.post_id = posts.id) AS like_count,
    (SELECT COUNT(*) FROM likes WHERE likes.post_id = posts.id AND likes.user_id = '{$_SESSION['user_id']}') AS is_liked,
    (SELECT COUNT(*) FROM favourites WHERE favourites.post_id = posts.id AND favourites.user_id = '{$_SESSION['user_id']}') AS is_favourite
    FROM posts
    JOIN users ON posts.user_id = users.id
    ORDER BY like_count DESC
    LIMIT 3
");

// Fetch Current User Details
$user_id = $_SESSION['user_id'];
$user_result = mysqli_query($conn, "SELECT * FROM users WHERE id='$user_id'");
$user = mysqli_fetch_assoc($user_result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trending</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #f9f9f9;
        }

        /* Simple Header */
        .simple-header {
            position: fixed;
            top: 0;
            width: 100%;
            background-color: #fff;
            border-bottom: 1px solid #e0e0e0;
            padding: 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .simple-header .back-arrow {
            font-size: 24px;
            cursor: pointer;
        }

        .simple-header .title {
            font-size: 22px;
            font-weight: bold;
            color: rgb(0, 0, 0);
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
        }

        /* Posts Container */
        .container {
            width: 500px;
            margin: 80px auto 20px auto;
        }

        .post {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 15px;
            margin-bottom: 20px;
        }

        .post-header {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .post-header .profile {
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: opacity 0.2s;
        }

        .post-header .profile:hover {
            opacity: 0.8;
        }

        .post-header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .post-header h4 {
            margin: 0;
            font-size: 15px;
            font-weight: bold;
            color: #333;
        }

        .timestamp {
            font-size: 12px;
            color: #888;
            margin-top: 2px;
        }

        .post-content {
            margin-top: 8px;
        }

        .post-content p {
            font-size: 15px;
            line-height: 1.4;
            margin-bottom: 8px;
        }

        /* Media Container */
        .media-container {
            width: 100%;
            height: 300px; /* Fixed height for all media */
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0; /* Light background for media container */
            border-radius: 10px;
            overflow: hidden; /* Ensure media doesn't overflow */
            margin-top: 8px;
        }

        .post-content img,
        .post-content video {
            width: 100%;
            height: 100%;
            object-fit: contain; /* Ensure media is fully visible without cropping */
            border-radius: 10px;
        }

        .post-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 8px;
            padding-top: 8px;
            border-top: 1px solid #e0e0e0; /* Added border for separation */
        }

        /* Like Icon */
        .like {
            font-size: 20px;
            cursor: pointer;
            transition: color 0.3s;
            color: #333; /* Default color for outlined icon */
        }

        .like.filled i {
            color: #ffcc00; /* Yellow color for filled icon */
        }

        .like i {
            transition: color 0.3s;
        }

        /* Favourite Icon */
        .heart {
            font-size: 20px;
            cursor: pointer;
            transition: color 0.3s;
        }

        .heart.filled {
            color: red;
        }
    </style>
</head>
<body>

<!-- Simple Header -->
<div class="simple-header">
    <i class="fas fa-arrow-left back-arrow" onclick="redirectToHome()"></i>
    <div class="title">Trending</div>
</div>

<!-- Posts Section -->
<div class="container">
    <?php while ($row = mysqli_fetch_assoc($trending_result)): ?>
    <div class="post">
        <div class="post-header">
            <div class="profile" onclick="redirectToProfile(<?php echo $row['user_id']; ?>)">
                <img src="<?php echo $row['profile_picture']; ?>">
                <div>
                    <h4><?php echo $row['name']; ?></h4>
                    <span class="timestamp"><?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?></span>
                </div>
            </div>
        </div>
        <p><?php echo highlightHashtags($row['post_text']); ?></p>
        <div class="post-content">
            <?php if (!empty($row['post_image'])): ?>
                <div class="media-container">
                    <?php if (strpos($row['post_image'], 'mp4') === false): ?>
                        <img src="<?php echo $row['post_image']; ?>">
                    <?php else: ?>
                        <video controls>
                            <source src="<?php echo $row['post_image']; ?>">
                        </video>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Like and Favourite Icons -->
        <div class="post-footer">
            <span 
                class="like <?php echo ($row['is_liked'] == 1) ? 'filled' : ''; ?>" 
                onclick="toggleLike(<?php echo $row['id']; ?>, this)">
                <i class="far fa-thumbs-up"></i>
                <span class="like-count"><?php echo $row['like_count']; ?></span>
            </span>
            <span 
                class="heart <?php echo ($row['is_favourite'] == 1) ? 'filled' : ''; ?>" 
                onclick="toggleFavourite(<?php echo $row['id']; ?>, this)">
                ♥
            </span>
        </div>
    </div>
    <?php endwhile; ?>
</div>

<script>
function redirectToHome() {
    window.location.href = "home.php";
}

function redirectToProfile(userId) {
    window.location.href = "profile.php?user_id=" + userId;
}

function toggleLike(postId, element) {
    fetch('toggle_like.php', {
        method: 'POST',
        body: JSON.stringify({ post_id: postId }),
        headers: { 'Content-Type': 'application/json' }
    }).then(response => response.json())
      .then(data => {
          if (data.success) {
              element.classList.toggle('filled');
              element.querySelector('.like-count').innerText = data.like_count;
          }
      });
}

function toggleFavourite(postId, element) {
    fetch('toggle_favourite.php', {
        method: 'POST',
        body: JSON.stringify({ post_id: postId }),
        headers: { 'Content-Type': 'application/json' }
    }).then(() => {
        element.classList.toggle('filled');
    });
}
</script>
</body>
</html>