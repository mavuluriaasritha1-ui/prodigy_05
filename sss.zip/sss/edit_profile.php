<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error);
}

$user_id = $_SESSION['user_id'];
$user_result = mysqli_query($conn, "SELECT * FROM users WHERE id='$user_id'");
$user = mysqli_fetch_assoc($user_result);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $bio = mysqli_real_escape_string($conn, $_POST['bio']);

    $profile_picture = $user['profile_picture'];
    $cover_photo = $user['cover_photo'];

    if (!empty($_FILES['profile_picture']['name'])) {
        $profile_picture = 'uploads/' . time() . '_' . $_FILES['profile_picture']['name'];
        move_uploaded_file($_FILES['profile_picture']['tmp_name'], $profile_picture);
    }

    if (!empty($_FILES['cover_photo']['name'])) {
        $cover_photo = 'uploads/' . time() . '_' . $_FILES['cover_photo']['name'];
        move_uploaded_file($_FILES['cover_photo']['tmp_name'], $cover_photo);
    }

    mysqli_query($conn, "UPDATE users SET name='$name', bio='$bio', profile_picture='$profile_picture', cover_photo='$cover_photo' WHERE id='$user_id'");
    header("Location: profile.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body { background-color: #f5f5f5; margin: 0; padding: 0; }

        body {
    font-family: Arial, sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh; /* Ensure the body takes the full height of the viewport */
}

/* Header */
.header {
    position: fixed;
    top: 0;
    width: 100%;
    background-color: #fff;
    border-bottom: 1px solid #e0e0e0;
    padding: 15px;
    display: flex;
    align-items: center;
    z-index: 1000;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.header .back-arrow {
    font-size: 24px;
    cursor: pointer;
    color: #000;
    margin-left: 10px; /* Move the arrow slightly to the right */
}

.header .title {
    font-size: 22px;
    font-weight: bold;
    color: #000;
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
}

/* Edit Container */
.edit-container {
    width: 400px;
    padding: 20px;
    background: white;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
    text-align: center;
    margin-top: 60px; /* Adjusted margin for header */
}

        h2 { margin-bottom: 15px; }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .profile-preview {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
        }

        .cover-preview {
            width: 100%;
            height: 120px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<!-- Header -->
<div class="header">
    <i class="fas fa-arrow-left back-arrow" onclick="window.location.href='profile.php'"></i>
    <div class="title">Edit Profile</div>
</div>

<!-- Edit Container -->
<div class="edit-container">
    <form method="post" enctype="multipart/form-data">
        <input type="text" name="name" value="<?php echo $user['name']; ?>" placeholder="Name" required>
        <textarea name="bio" placeholder="Bio"><?php echo $user['bio']; ?></textarea>

        <label>Profile Picture</label><br>
        <img src="<?php echo $user['profile_picture']; ?>" class="profile-preview" id="profilePreview"><br>
        <input type="file" name="profile_picture" accept="image/*" onchange="previewImage(event, 'profilePreview')">

        <label>Cover Photo</label><br>
        <img src="<?php echo $user['cover_photo']; ?>" class="cover-preview" id="coverPreview"><br>
        <input type="file" name="cover_photo" accept="image/*" onchange="previewImage(event, 'coverPreview')">

        <button type="submit">Save Changes</button>
    </form>
</div>

<script>
function previewImage(event, previewId) {
    var reader = new FileReader();
    reader.onload = function(){
        var output = document.getElementById(previewId);
        output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
}
</script>

</body>
</html>