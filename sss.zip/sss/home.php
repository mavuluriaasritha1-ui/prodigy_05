<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch All Posts
$result = mysqli_query($conn, "
    SELECT posts.*, users.name, users.profile_picture,
    IF(favourites.id IS NOT NULL, 1, 0) AS is_favourite,
    (SELECT COUNT(*) FROM likes WHERE likes.post_id = posts.id) AS like_count,
    (SELECT COUNT(*) FROM likes WHERE likes.post_id = posts.id AND likes.user_id = '{$_SESSION['user_id']}') AS is_liked
    FROM posts
    JOIN users ON posts.user_id = users.id
    LEFT JOIN favourites ON posts.id = favourites.post_id AND favourites.user_id = '{$_SESSION['user_id']}'
    ORDER BY posts.id DESC
");

// Fetch Current User Details
$user_id = $_SESSION['user_id'];
$user_result = mysqli_query($conn, "SELECT * FROM users WHERE id='$user_id'");
$user = mysqli_fetch_assoc($user_result);

// Fetch Unseen Message Count
$unseen_message_count_query = mysqli_query($conn, "
    SELECT COUNT(DISTINCT sender_id) AS unseen_count 
    FROM messages 
    WHERE conversation_id IN (
        SELECT conversation_id 
        FROM messages 
        WHERE sender_id = '$user_id'
    ) 
    AND sender_id != '$user_id' 
    AND seen = 0
");
$unseen_message_count = mysqli_fetch_assoc($unseen_message_count_query)['unseen_count'];

// Function to highlight hashtags
function highlightHashtags($text) {
    return preg_replace('/#(\w+)/', '<span style="color: blue;">#$1</span>', $text);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #f9f9f9;
        }

        /* Fixed Header */
        .header {
            position: fixed;
            top: 0;
            width: 100%;
            background-color: #fff;
            border-bottom: 1px solid #e0e0e0;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .header .logo {
            width: 50px;
            height: 40px;
        }

        .header .title {
            flex-grow: 1;
            text-align: center;
            font-size: 22px;
            font-weight: bold;
            color:rgb(0, 0, 0);
        }

        .header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .header img:hover {
            transform: scale(1.1);
        }

        /* Icons Container */
        .icons-container {
            display: flex;
            align-items: center;
            gap: 30px; /* Increased space between icons */
        }

        .icons-container a {
            text-decoration: none;
            color: #333;
            position: relative;
        }

        .icons-container a i {
            font-size: 20px;
        }

        .unseen-message-count {
            position: absolute;
            top: -5px;
            right: -10px;
            background-color: red;
            color: white;
            font-size: 12px;
            padding: 2px 6px;
            border-radius: 50%;
        }

        /* Search Container */
        .search-container {
            position: relative;
            display: flex;
            align-items: center;
        }

        .search-container input {
            padding: 8px 12px;
            border: 1px solid #ccc;
            border-radius: 20px;
            outline: none;
            width: 0;
            transition: width 0.3s;
            opacity: 0;
        }

        .search-container input.active {
            width: 200px;
            opacity: 1;
        }

        .search-container button {
            background: none;
            border: none;
            cursor: pointer;
            font-size: 18px;
            color: #333;
        }

        .search-results {
            position: absolute;
            top: 40px;
            left: 0;
            width: 200px;
            background: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            max-height: 200px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
        }

        .search-results div {
            display: flex;
            align-items: center;
            padding: 10px;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .search-results div:hover {
            background-color: #f5f5f5;
        }

        .search-results img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .search-results span {
            font-size: 14px;
            color: #333;
        }

        /* Sidebar Profile */
        .profile-sidebar {
            position: fixed;
            top: 60px;
            right: -300px;
            width: 250px;
            height: 100%;
            background-color: #fff;
            box-shadow: -2px 0 10px rgba(0, 0, 0, 0.1);
            transition: 0.3s;
            padding: 20px;
        }

        .profile-sidebar.show {
            right: 0;
        }

        .profile-sidebar img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
        }

        .profile-sidebar h4 {
            margin-top: 10px;
            font-size: 18px;
            color: #333;
        }

        .profile-sidebar a {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: #333;
            padding: 12px 0;
            transition: background-color 0.2s;
        }

        .profile-sidebar a i {
            margin-right: 10px;
            font-size: 18px;
        }

        .profile-sidebar a:hover {
            background-color: #f5f5f5;
            border-radius: 5px;
        }

        .logout {
            color: red;
        }

        /* Posts Container */
        .container {
            width: 500px;
            margin: 80px auto 20px auto;
        }

        .post {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 12px;
            margin-bottom: 10px;
        }

        .post-header {
            display: flex;
            align-items: center;
            margin-bottom: 8px;
        }

        .post-header .profile {
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: opacity 0.2s;
        }

        .post-header .profile:hover {
            opacity: 0.8;
        }

        .post-header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .post-header h4 {
            margin: 0;
            font-size: 15px;
            font-weight: bold;
            color: #333;
        }

        .timestamp {
            font-size: 12px;
            color: #888;
            margin-top: 2px;
        }

        .post-content {
            margin-top: 8px;
        }

        .post-content p {
            font-size: 15px;
            line-height: 1.4;
            margin-bottom: 8px;
        }

        /* Media Container */
        .media-container {
            width: 100%;
            height: 300px;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
            border-radius: 10px;
            overflow: hidden;
            margin-top: 8px;
        }

        .post-content img,
        .post-content video {
            width: 100%;
            height: 100%;
            object-fit: contain;
            border-radius: 10px;
        }

        .post-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 8px;
            padding-top: 8px;
            border-top: 1px solid #e0e0e0;
        }

        /* Like Icon */
        .like {
            font-size: 20px;
            cursor: pointer;
            transition: color 0.3s;
            color: #333;
        }

        .like.filled i {
            color: #ffcc00;
        }

        .like i {
            transition: color 0.3s;
        }

        /* Favourite Icon */
        .heart {
            font-size: 20px;
            cursor: pointer;
            transition: color 0.3s;
        }

        .heart.filled {
            color: red;
        }
    </style>
</head>
<body>

<!-- Fixed Header -->
<div class="header">
    <img src="uploads/logo.jpg" class="logo">
    <div class="title">ChitChatz</div>
    <div class="icons-container">
        <a href="search.php">
            <i class="fas fa-search"></i>
        </a>
        <a href="messages.php">
            <i class="fas fa-envelope"></i>
            <?php if ($unseen_message_count > 0): ?>
                <span class="unseen-message-count"><?php echo $unseen_message_count; ?></span>
            <?php endif; ?>
        </a>
        <img src="<?php echo $user['profile_picture']; ?>" onclick="toggleSidebar()">
    </div>
</div>

<!-- Profile Sidebar -->
<div class="profile-sidebar" id="profileSidebar">
    <center>
        <img src="<?php echo $user['profile_picture']; ?>">
        <h4><?php echo $user['name']; ?></h4>
    </center>
    <hr>
    <a href="profile.php?user_id=<?php echo $user_id; ?>"><i class="fas fa-user"></i> Profile</a>
    <a href="create_post.php"><i class="fas fa-pencil-alt"></i> Create Post</a>
    <a href="messages.php"><i class="fas fa-message"></i> Message</a>
    <a href="trending.php"><i class="fas fa-fire"></i> Trending</a>
    <a href="logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- Posts Section -->
<div class="container">
    <?php while ($row = mysqli_fetch_assoc($result)): ?>
    <div class="post">
        <div class="post-header">
            <div class="profile" onclick="redirectToProfile(<?php echo $row['user_id']; ?>)">
                <img src="<?php echo $row['profile_picture']; ?>">
                <div>
                    <h4><?php echo $row['name']; ?></h4>
                    <span class="timestamp"><?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?></span>
                </div>
            </div>
        </div>
        
        <div class="post-content">
            <p><?php echo highlightHashtags($row['post_text']); ?></p>
            <?php if (!empty($row['post_image'])): ?>
                <div class="media-container">
                    <?php if (strpos($row['post_image'], 'mp4') === false): ?>
                        <img src="<?php echo $row['post_image']; ?>">
                    <?php else: ?>
                        <video controls>
                            <source src="<?php echo $row['post_image']; ?>">
                        </video>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Like and Favourite Icons -->
        <div class="post-footer">
            <span 
                class="like <?php echo ($row['is_liked'] == 1) ? 'filled' : ''; ?>" 
                onclick="toggleLike(<?php echo $row['id']; ?>, this)">
                <i class="far fa-thumbs-up"></i>
                <span class="like-count"><?php echo $row['like_count']; ?></span>
            </span>
            <span 
                class="heart <?php echo ($row['is_favourite'] == 1) ? 'filled' : ''; ?>" 
                onclick="toggleFavourite(<?php echo $row['id']; ?>, this)">
                ♥
            </span>
        </div>
    </div>
    <?php endwhile; ?>
</div>

<script>
function toggleSidebar() {
    document.getElementById('profileSidebar').classList.toggle('show');
}

function redirectToProfile(userId) {
    window.location.href = "profile.php?user_id=" + userId;
}

function toggleLike(postId, element) {
    fetch('toggle_like.php', {
        method: 'POST',
        body: JSON.stringify({ post_id: postId }),
        headers: { 'Content-Type': 'application/json' }
    }).then(response => response.json())
      .then(data => {
          if (data.success) {
              element.classList.toggle('filled');
              element.querySelector('.like-count').innerText = data.like_count;
          }
      });
}

function toggleFavourite(postId, element) {
    fetch('toggle_favourite.php', {
        method: 'POST',
        body: JSON.stringify({ post_id: postId }),
        headers: { 'Content-Type': 'application/json' }
    }).then(() => {
        element.classList.toggle('filled');
    });
}

// Search Functionality
function toggleSearch() {
    const searchInput = document.getElementById('searchInput');
    searchInput.classList.toggle('active');
    searchInput.focus();
}

function fetchUsers(query) {
    if (query.length === 0) {
        document.getElementById('searchResults').style.display = 'none';
        return;
    }

    fetch('search_users.php?query=' + query)
        .then(response => response.json())
        .then(data => {
            const resultsContainer = document.getElementById('searchResults');
            resultsContainer.innerHTML = '';
            if (data.length > 0) {
                data.forEach(user => {
                    const div = document.createElement('div');
                    div.innerHTML = `
                        <img src="${user.profile_picture}" alt="${user.name}">
                        <span>${user.name}</span>
                    `;
                    div.onclick = () => redirectToProfile(user.id);
                    resultsContainer.appendChild(div);
                });
                resultsContainer.style.display = 'block';
            } else {
                resultsContainer.style.display = 'none';
            }
        });
}
</script>
</body>
</html>