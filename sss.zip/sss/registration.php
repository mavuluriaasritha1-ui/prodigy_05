<?php
$image_path = 'img/img1.jpg';
if (!file_exists($image_path)) {
    $image_path = 'img/img1.jpeg'; // Fallback image
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-image: url('uploads/background.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 400px;
            padding: 30px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .container h2 {
            font-size: 30px;
            font-weight: 500;
            color: black;
            margin-bottom: 20px;
            text-align: center;
        }

        .profile-pic-container {
            position: relative;
            width: 100px;
            height: 100px;
            margin: 10px auto;
        }

        .profile-pic {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #0aa5e3;
        }

        .input-group {
            position: relative;
            width: 100%;
            margin-bottom: 20px;
        }

        .input-group input,
        .input-group select,
        .input-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background: #f0f0f0;
            color: #000;
            font-size: 14px;
            outline: none;
        }

        .input-group textarea {
            resize: none;
            height: 80px;
        }

        .input-group label {
            position: absolute;
            top: 50%;
            left: 12px;
            transform: translateY(-50%);
            font-size: 14px;
            font-weight: bold;
            color: #555;
            transition: 0.3s;
            pointer-events: none;
        }

        .input-group input:focus + label,
        .input-group input:not(:placeholder-shown) + label,
        .input-group select:focus + label,
        .input-group select:not(:placeholder-shown) + label,
        .input-group textarea:focus + label,
        .input-group textarea:not(:placeholder-shown) + label {
            top: 5px;
            font-size: 12px;
            color: #007bff;
        }

        .file-container {
            position: relative;
            width: 100%;
            margin-top: 15px;
            text-align: left;
        }

        .file-container label {
            display: block;
            font-size: 14px;
            color: black;
            margin-bottom: 5px;
        }

        .file-container input {
            width: 100%;
            padding: 12px;
            background: rgba(0, 0, 0, 0.07);
            border-radius: 5px;
            border: none;
            outline: none;
            font-size: 14px;
            color: black;
            cursor: pointer;
        }

        button {
            margin-top: 20px;
            width: 100%;
            background-color: #0aa5e3;
            color: #fff;
            padding: 15px 0;
            font-size: 18px;
            font-weight: 600;
            border-radius: 5px;
            cursor: pointer;
            border: none;
        }

        button:hover {
            background-color: #0894c2;
        }

        p {
            text-align: center;
            margin-top: 10px;
        }

        a {
            color:rgb(255, 255, 255);
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
   

    <!-- Profile Picture Preview (No Upload Here) -->
    <div class="profile-pic-container">
        <img src="default.jpg" id="profileImage" class="profile-pic">
    </div>

    <form action="auth.php" method="POST" enctype="multipart/form-data">
        <!-- Name Field -->
        <div class="input-group">
            <input type="text" name="name" placeholder=" " required>
            <label>Name</label>
        </div>

        <!-- Email Field -->
        <div class="input-group">
            <input type="email" name="email" placeholder=" " required>
            <label>Email</label>
        </div>

        <!-- Password Field -->
        <div class="input-group">
            <input type="password" name="password" placeholder=" " required>
            <label>Password</label>
        </div>

        <!-- Contact Number Field -->
        <div class="input-group">
            <input type="text" name="contact_number" placeholder=" " required>
            <label>Contact Number</label>
        </div>

        <!-- Gender Field -->
        <div class="input-group">
            <select name="gender" required>
                <option value="" disabled selected></option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>
            <label>Gender</label>
        </div>

        <!-- Bio Field -->
        <div class="input-group">
            <textarea name="bio" placeholder=" " required></textarea>
            <label>Bio</label>
        </div>

        <!-- Profile Photo Upload -->
        <div class="file-container">
            <label>Profile Photo</label>
            <input type="file" name="profile_photo" accept="image/*" required onchange="previewProfileImage(event)">
        </div>

        <!-- Cover Photo Upload -->
        <div class="file-container">
            <label>Cover Photo</label>
            <input type="file" name="cover_photo" accept="image/*" required>
        </div>

        <!-- Submit Button -->
        <button type="submit" name="register">Register</button>
    </form>

    <p>Already have an account? <a href="login.php">Login here</a></p>
</div>

<script>
    function previewProfileImage(event) {
        const reader = new FileReader();
        reader.onload = function() {
            document.getElementById('profileImage').src = reader.result;
        };
        reader.readAsDataURL(event.target.files[0]);
    }
</script>

</body>
</html>