<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$logged_in_user_id = $_SESSION['user_id'];
$recipient_user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;

// Fetch all conversations for the logged-in user with the last message
$conversations_query = "
    SELECT c.id, u.id AS user_id, u.name, u.profile_picture, 
           (SELECT message FROM messages WHERE conversation_id = c.id ORDER BY created_at DESC LIMIT 1) AS last_message,
           (SELECT created_at FROM messages WHERE conversation_id = c.id ORDER BY created_at DESC LIMIT 1) AS last_message_time,
           (SELECT COUNT(*) FROM messages WHERE conversation_id = c.id AND sender_id != '$logged_in_user_id' AND seen = 0) AS unseen_count
    FROM conversations c 
    JOIN users u ON (c.user1_id = u.id OR c.user2_id = u.id) AND u.id != '$logged_in_user_id' 
    WHERE c.user1_id = '$logged_in_user_id' OR c.user2_id = '$logged_in_user_id'
    ORDER BY last_message_time DESC
";
$conversations_result = mysqli_query($conn, $conversations_query);
$conversations = mysqli_fetch_all($conversations_result, MYSQLI_ASSOC);

// Fetch recipient user details and messages if a recipient is selected
$recipient_user = null;
$messages = [];
if ($recipient_user_id) {
    $recipient_result = mysqli_query($conn, "SELECT * FROM users WHERE id='$recipient_user_id'");
    $recipient_user = mysqli_fetch_assoc($recipient_result);

    // Fetch messages for the selected conversation
    $conversation_query = "
        SELECT id FROM conversations 
        WHERE (user1_id = '$logged_in_user_id' AND user2_id = '$recipient_user_id') 
        OR (user1_id = '$recipient_user_id' AND user2_id = '$logged_in_user_id')
    ";
    $conversation_result = mysqli_query($conn, $conversation_query);

    if (mysqli_num_rows($conversation_result) > 0) {
        $conversation = mysqli_fetch_assoc($conversation_result);
        $conversation_id = $conversation['id'];

        $messages_query = "
            SELECT messages.*, users.profile_picture, users.name 
            FROM messages 
            JOIN users ON messages.sender_id = users.id 
            WHERE conversation_id = '$conversation_id' 
            ORDER BY created_at ASC
        ";
        $messages_result = mysqli_query($conn, $messages_query);
        $messages = mysqli_fetch_all($messages_result, MYSQLI_ASSOC);

        // Mark messages as seen
        mysqli_query($conn, "
            UPDATE messages 
            SET seen = 1 
            WHERE conversation_id = '$conversation_id' 
            AND sender_id != '$logged_in_user_id'
        ");
    }
}

// Handle sending a message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Check if a conversation already exists between the two users
    $conversation_query = "
        SELECT id FROM conversations 
        WHERE (user1_id = '$logged_in_user_id' AND user2_id = '$recipient_user_id') 
        OR (user1_id = '$recipient_user_id' AND user2_id = '$logged_in_user_id')
    ";
    $conversation_result = mysqli_query($conn, $conversation_query);

    if (mysqli_num_rows($conversation_result) > 0) {
        // Use existing conversation
        $conversation = mysqli_fetch_assoc($conversation_result);
        $conversation_id = $conversation['id'];
    } else {
        // Create a new conversation
        $insert_conversation_query = "
            INSERT INTO conversations (user1_id, user2_id) 
            VALUES ('$logged_in_user_id', '$recipient_user_id')
        ";
        mysqli_query($conn, $insert_conversation_query);
        $conversation_id = mysqli_insert_id($conn);
    }

    // Insert the message into the messages table
    $insert_message_query = "
        INSERT INTO messages (conversation_id, sender_id, message) 
        VALUES ('$conversation_id', '$logged_in_user_id', '$message')
    ";
    mysqli_query($conn, $insert_message_query);

    // Redirect to refresh the page and show the new message
    header("Location: messages.php?user_id=$recipient_user_id");
    exit();
}

// Handle message deletion
if (isset($_GET['delete_message_id'])) {
    $message_id = mysqli_real_escape_string($conn, $_GET['delete_message_id']);
    $delete_query = "DELETE FROM messages WHERE id = '$message_id' AND sender_id = '$logged_in_user_id'";
    mysqli_query($conn, $delete_query);
    header("Location: messages.php?user_id=$recipient_user_id");
    exit();
}

// Handle message editing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_message_id'])) {
    $message_id = mysqli_real_escape_string($conn, $_POST['edit_message_id']);
    $new_message = mysqli_real_escape_string($conn, $_POST['new_message']);
    $update_query = "UPDATE messages SET message = '$new_message' WHERE id = '$message_id' AND sender_id = '$logged_in_user_id'";
    mysqli_query($conn, $update_query);
    header("Location: messages.php?user_id=$recipient_user_id");
    exit();
}

// Handle user search
if (isset($_GET['search'])) {
    $search_term = mysqli_real_escape_string($conn, $_GET['search']);
    $search_query = "
        SELECT * FROM users 
        WHERE name LIKE '%$search_term%' AND id != '$logged_in_user_id'
    ";
    $search_result = mysqli_query($conn, $search_query);
    $search_results = mysqli_fetch_all($search_result, MYSQLI_ASSOC);

    // Return search results as HTML
    if (!empty($search_results)) {
        foreach ($search_results as $user) {
            echo "<li class='search-item' onclick=\"openChat('{$user['id']}')\">
                    <img src='{$user['profile_picture']}' alt='{$user['name']}'>
                    <span>{$user['name']}</span>
                  </li>";
        }
    } else {
        echo "<li class='no-results'>No users found.</li>";
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            height: 100vh;
            background-color: #fafafa;
        }

        .sidebar {
            width: 35%;
            max-width: 400px;
            background: white;
            border-right: 1px solid #dbdbdb;
            overflow-y: auto;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #dbdbdb;
            font-size: 18px;
            font-weight: 600;
            background: white;
        }

        .back-arrow {
            font-size: 24px;
            margin-right: 10px;
            cursor: pointer;
        }

        .search-bar {
            padding: 10px;
            border-bottom: 1px solid #dbdbdb;
            background: white;
        }

        .search-bar input {
            width: 100%;
            padding: 8px;
            border: 1px solid #dbdbdb;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
        }

        .search-results {
            list-style: none;
            padding: 0;
            margin: 0;
            background: white;
        }

        .search-item {
            display: flex;
            align-items: center;
            padding: 10px;
            cursor: pointer;
        }

        .search-item:hover {
            background-color: #f5f5f5;
        }

        .search-item img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .no-results {
            padding: 10px;
            color: #8e8e8e;
            text-align: center;
        }

        .chat-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .chat-item {
            display: flex;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #dbdbdb;
            cursor: pointer;
        }

        .chat-item:hover {
            background-color: #f5f5f5;
        }

        .chat-item img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .chat-item-info {
            flex: 1;
        }

        .chat-item-name {
            font-size: 14px;
            font-weight: 600;
        }

        .chat-item-last-message {
            font-size: 12px;
            color: #8e8e8e;
        }

        .unseen-count {
            background: #0095f6;
            color: white;
            font-size: 12px;
            padding: 2px 6px;
            border-radius: 50%;
            margin-left: auto;
        }

        .chat-window {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: white;
            width: 65%;
        }

        .chat-window-header {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #dbdbdb;
            background: white;
        }

        .chat-window-header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .chat-window-header h3 {
            margin: 0;
            font-size: 16px;
            font-weight: 600;
        }

        .messages-list {
            flex: 1;
            padding: 15px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .message {
            display: flex;
            align-items: flex-start;
            max-width: 70%;
            position: relative;
        }

        .message.sent {
            margin-left: auto;
        }

        .message.received {
            margin-right: auto;
        }

        .message img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .message-content {
            background: #efefef;
            padding: 10px;
            border-radius: 15px;
            font-size: 14px;
            line-height: 1.4;
            cursor: pointer;
        }

        .message.sent .message-content {
            background: #0095f6;
            color: white;
            border-radius: 15px 15px 0 15px;
        }

        .message.received .message-content {
            background: #efefef;
            color: black;
            border-radius: 15px 15px 15px 0;
        }

        .no-messages {
            text-align: center;
            color: #8e8e8e;
            margin-top: 20px;
        }

        .message-form {
            display: flex;
            gap: 10px;
            padding: 15px;
            border-top: 1px solid #dbdbdb;
            background: white;
            align-items: center;
        }

        .message-form textarea {
            flex: 1;
            padding: 10px;
            border: 1px solid #dbdbdb;
            border-radius: 8px;
            resize: none;
            font-size: 14px;
            outline: none;
        }

        .message-form button {
            padding: 10px 20px;
            background: #0095f6;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
        }

        .message-form button:hover {
            background: #0077cc;
        }

        .message-options {
            position: absolute;
            top: 0;
            left: -100px; /* Move the dropdown to the left */
            background: white;
            border: 1px solid #dbdbdb;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            display: none;
            z-index: 1000;
            width: 100px; /* Set a fixed width for the dropdown */
        }

        .message-options button {
            display: block;
            width: 100%;
            padding: 8px 16px;
            background: none;
            border: none;
            text-align: left;
            font-size: 14px;
            cursor: pointer;
        }

        .message-options button:hover {
            background: #f5f5f5;
        }
    </style>
</head>
<body>
    <!-- Sidebar for chat list -->
    <div class="sidebar">
        <div class="sidebar-header">
            <span class="back-arrow" onclick="window.location.href='home.php'">←</span>
            Chats
        </div>
        <div class="search-bar">
            <input type="text" id="search-input" placeholder="Search users..." oninput="searchUsers(this.value)">
        </div>
        <ul class="search-results" id="search-results"></ul>
        <ul class="chat-list" id="chat-list">
            <?php foreach ($conversations as $conversation): ?>
                <li class="chat-item" onclick="window.location.href='messages.php?user_id=<?php echo $conversation['user_id']; ?>'">
                    <img src="<?php echo $conversation['profile_picture']; ?>" alt="<?php echo $conversation['name']; ?>">
                    <div class="chat-item-info">
                        <div class="chat-item-name"><?php echo $conversation['name']; ?></div>
                        <div class="chat-item-last-message"><?php echo $conversation['last_message']; ?></div>
                    </div>
                    <?php if ($conversation['unseen_count'] > 0): ?>
                        <div class="unseen-count"><?php echo $conversation['unseen_count']; ?></div>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <!-- Chat window -->
    <div class="chat-window">
        <?php if ($recipient_user): ?>
            <div class="chat-window-header">
                <img src="<?php echo $recipient_user['profile_picture']; ?>" alt="<?php echo $recipient_user['name']; ?>">
                <h3><?php echo $recipient_user['name']; ?></h3>
            </div>

            <div class="messages-list">
                <?php if (empty($messages)): ?>
                    <div class="no-messages">No conversations yet. Start the conversation!</div>
                <?php else: ?>
                    <?php foreach ($messages as $message): ?>
                        <div class="message <?php echo $message['sender_id'] == $logged_in_user_id ? 'sent' : 'received'; ?>">
                            <?php if ($message['sender_id'] != $logged_in_user_id): ?>
                                <img src="<?php echo $message['profile_picture']; ?>" alt="<?php echo $message['name']; ?>">
                            <?php endif; ?>
                            <div class="message-content" onclick="toggleMessageOptions('<?php echo $message['id']; ?>')">
                                <?php echo nl2br(htmlspecialchars($message['message'])); ?>
                            </div>
                            <?php if ($message['sender_id'] == $logged_in_user_id): ?>
                                <div class="message-options" id="message-options-<?php echo $message['id']; ?>">
                                    <button onclick="editMessage('<?php echo $message['id']; ?>')">Edit</button>
                                    <button onclick="deleteMessage('<?php echo $message['id']; ?>')">Delete</button>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <form class="message-form" method="POST">
                <textarea name="message" id="message-input" placeholder="Type your message..." required></textarea>
                <button type="submit">Send</button>
            </form>
        <?php else: ?>
            <div class="no-messages" style="text-align: center; margin-top: 50px;">
                Select a chat to start messaging.
            </div>
        <?php endif; ?>
    </div>

        <script>
            // Automatically scroll to the bottom of the messages list
            const messagesList = document.querySelector('.messages-list');
            if (messagesList) {
                messagesList.scrollTop = messagesList.scrollHeight;
            }

            // Function to search users
            function searchUsers(query) {
                const chatList = document.getElementById('chat-list');
                const searchResults = document.getElementById('search-results');

                if (query.length > 0) {
                    fetch(`messages.php?search=${query}`)
                        .then(response => response.text())
                        .then(data => {
                            searchResults.innerHTML = data;
                            chatList.style.display = 'none';
                        });
                } else {
                    searchResults.innerHTML = '';
                    chatList.style.display = 'block';
                }
            }

            // Function to open chat with a user
            function openChat(userId) {
                window.location.href = `messages.php?user_id=${userId}`;
            }

            // Function to toggle message options
            function toggleMessageOptions(messageId) {
                const messageOptions = document.getElementById(`message-options-${messageId}`);
                messageOptions.style.display = messageOptions.style.display === 'block' ? 'none' : 'block';
            }

            // Function to delete a message
            function deleteMessage(messageId) {
                if (confirm("Are you sure you want to delete this message?")) {
                    window.location.href = `messages.php?user_id=<?php echo $recipient_user_id; ?>&delete_message_id=${messageId}`;
                }
            }

            // Function to edit a message
            function editMessage(messageId) {
                const messageContent = document.querySelector(`#message-options-${messageId}`).previousElementSibling;
                const newMessage = prompt("Edit your message:", messageContent.innerText.trim());
                if (newMessage !== null) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.style.display = 'none';

                    const messageIdInput = document.createElement('input');
                    messageIdInput.type = 'hidden';
                    messageIdInput.name = 'edit_message_id';
                    messageIdInput.value = messageId;

                    const newMessageInput = document.createElement('input');
                    newMessageInput.type = 'hidden';
                    newMessageInput.name = 'new_message';
                    newMessageInput.value = newMessage;

                    form.appendChild(messageIdInput);
                    form.appendChild(newMessageInput);
                    document.body.appendChild(form);
                    form.submit();
                }
            }
        </script>
    </body>
    </html>