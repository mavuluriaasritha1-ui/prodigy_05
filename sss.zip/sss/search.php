<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch Current User Details
$user_id = $_SESSION['user_id'];
$user_result = mysqli_query($conn, "SELECT * FROM users WHERE id='$user_id'");
$user = mysqli_fetch_assoc($user_result);

// Handle adding a recent search
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_recent_search'])) {
    $searched_user_id = $_POST['searched_user_id'];
    // Check if the search already exists for the user
    $check_sql = "SELECT * FROM recent_searches WHERE user_id = '$user_id' AND searched_user_id = '$searched_user_id'";
    $check_result = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($check_result) > 0) {
        // Update the timestamp if the search already exists
        $update_sql = "UPDATE recent_searches SET searched_at = CURRENT_TIMESTAMP WHERE user_id = '$user_id' AND searched_user_id = '$searched_user_id'";
        mysqli_query($conn, $update_sql);
    } else {
        // Add the search if it doesn't exist
        $insert_sql = "INSERT INTO recent_searches (user_id, searched_user_id) VALUES ('$user_id', '$searched_user_id')";
        mysqli_query($conn, $insert_sql);
    }
    echo json_encode(['success' => true]);
    exit();
}

// Handle removing a recent search
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_recent_search'])) {
    $searched_user_id = $_POST['searched_user_id'];
    // Remove the recent search
    $sql = "DELETE FROM recent_searches WHERE user_id = '$user_id' AND searched_user_id = '$searched_user_id'";
    mysqli_query($conn, $sql);
    echo json_encode(['success' => true]);
    exit();
}

// Fetch recent searches for the logged-in user
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['get_recent_searches'])) {
    $sql = "
        SELECT users.id, users.name, users.profile_picture 
        FROM recent_searches 
        JOIN users ON recent_searches.searched_user_id = users.id 
        WHERE recent_searches.user_id = '$user_id' 
        ORDER BY recent_searches.searched_at DESC 
        LIMIT 5
    ";
    $result = mysqli_query($conn, $sql);
    $recent_searches = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $recent_searches[] = $row;
    }
    echo json_encode($recent_searches);
    exit();
}

// Fetch users based on search query
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['query'])) {
    $query = $_GET['query'];
    $sql = "SELECT id, name, profile_picture FROM users WHERE name LIKE '%$query%' LIMIT 5";
    $result = mysqli_query($conn, $sql);
    $users = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $users[] = $row;
    }
    echo json_encode($users);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Users</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #f9f9f9;
        }

        .header {
            position: fixed;
            top: 0;
            width: 100%;
            background-color: #fff;
            border-bottom: 1px solid #e0e0e0;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .header .back-arrow {
            font-size: 24px;
            color: #333;
            cursor: pointer;
        }

        .header .title {
            flex-grow: 1;
            text-align: center;
            font-size: 22px;
            font-weight: bold;
            color:rgb(0, 0, 0);
        }

        .search-container {
            margin-top: 80px; /* Below the header */
            padding: 20px;
        }

        .search-container input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 20px;
            outline: none;
            font-size: 16px;
        }

        .search-results, .recent-searches {
            margin-top: 20px;
        }

        .search-results div, .recent-searches div {
            display: flex;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #e0e0e0;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .search-results div:hover, .recent-searches div:hover {
            background-color: #f5f5f5;
        }

        .search-results img, .recent-searches img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .search-results span, .recent-searches span {
            font-size: 16px;
            color: #333;
            flex-grow: 1;
        }

        .remove-search {
            font-size: 18px;
            color: #888;
            cursor: pointer;
        }

        .remove-search:hover {
            color: #333;
        }

        .no-results {
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
            color: #888;
        }
    </style>
</head>
<body>

<!-- Header -->
<div class="header">
    <div class="back-arrow" onclick="window.location.href='home.php'">←</div>
    <div class="title">Search Users</div>
</div>

<!-- Search Container -->
<div class="search-container">
    <input type="text" id="searchInput" placeholder="Search users..." oninput="handleInput(event)">
    <div class="recent-searches" id="recentSearches"></div>
    <div class="search-results" id="searchResults"></div>
    <div class="no-results" id="noResults" style="display: none;">No users found.</div>
</div>

<script>
// Load recent searches from the database
function loadRecentSearches() {
    fetch('?get_recent_searches=true')
        .then(response => response.json())
        .then(data => {
            const recentSearchesContainer = document.getElementById('recentSearches');
            recentSearchesContainer.innerHTML = '';

            data.forEach(user => {
                const div = document.createElement('div');
                div.innerHTML = `
                    <img src="${user.profile_picture}" alt="${user.name}">
                    <span>${user.name}</span>
                    <div class="remove-search" onclick="removeRecentSearch(${user.id}, event)">×</div>
                `;
                div.onclick = () => {
                    window.location.href = "profile.php?user_id=" + user.id;
                };
                recentSearchesContainer.appendChild(div);
            });
        });
}

// Add a user to recent searches
function addToRecentSearches(user) {
    fetch('', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `searched_user_id=${user.id}&add_recent_search=true`
    }).then(() => loadRecentSearches());
}

// Remove a user from recent searches
function removeRecentSearch(userId, event) {
    event.stopPropagation(); // Prevent the click event from bubbling up
    fetch('', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `searched_user_id=${userId}&remove_recent_search=true`
    }).then(() => loadRecentSearches());
}

// Fetch users based on search query
function fetchUsers(query) {
    const searchResultsContainer = document.getElementById('searchResults');
    const noResults = document.getElementById('noResults');

    fetch(`?query=${query}`)
        .then(response => response.json())
        .then(data => {
            searchResultsContainer.innerHTML = '';

            if (data.length > 0) {
                data.forEach(user => {
                    const div = document.createElement('div');
                    div.innerHTML = `
                        <img src="${user.profile_picture}" alt="${user.name}">
                        <span>${user.name}</span>
                    `;
                    div.onclick = () => {
                        addToRecentSearches(user); // Add to recent searches
                        window.location.href = "profile.php?user_id=" + user.id;
                    };
                    searchResultsContainer.appendChild(div);
                });
                noResults.style.display = 'none';
            } else {
                noResults.style.display = 'block';
            }
        });
}

// Handle input changes
function handleInput(event) {
    const query = event.target.value.trim();
    const recentSearchesContainer = document.getElementById('recentSearches');
    const searchResultsContainer = document.getElementById('searchResults');
    const noResults = document.getElementById('noResults');

    if (query.length === 0) {
        // Clear search results and show recent searches
        searchResultsContainer.innerHTML = '';
        noResults.style.display = 'none';
        loadRecentSearches();
    } else {
        // Hide recent searches and fetch search suggestions
        recentSearchesContainer.innerHTML = '';
        fetchUsers(query);
    }
}

// Load recent searches when the page loads
window.onload = loadRecentSearches;
</script>
</body>
</html>