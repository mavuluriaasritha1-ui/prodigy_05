<?php
session_start();
$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// User Registration
if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $contact_number = $_POST['contact_number'];
    $gender = $_POST['gender'];
    $bio = $_POST['bio'];

    // Ensure 'uploads' folder exists
    if (!file_exists('uploads')) {
        mkdir('uploads', 0777, true);
    }

    // Validate Profile Photo Upload
    if (!isset($_FILES["profile_photo"]) || $_FILES["profile_photo"]["error"] != 0) {
        die("Profile picture is required.");
    }

    // Validate Cover Photo Upload
    if (!isset($_FILES["cover_photo"]) || $_FILES["cover_photo"]["error"] != 0) {
        die("Cover photo is required.");
    }

    // Handle Profile Photo Upload
    $profile_target = "uploads/" . time() . "_" . basename($_FILES["profile_photo"]["name"]);
    move_uploaded_file($_FILES["profile_photo"]["tmp_name"], $profile_target);

    // Handle Cover Photo Upload
    $cover_target = "uploads/" . time() . "_" . basename($_FILES["cover_photo"]["name"]);
    move_uploaded_file($_FILES["cover_photo"]["tmp_name"], $cover_target);

    // Insert user into database
    $stmt = $conn->prepare("INSERT INTO users (name, email, password, contact_number, gender, bio, profile_picture, cover_photo) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $name, $email, $password, $contact_number, $gender, $bio, $profile_target, $cover_target);

    if ($stmt->execute()) {
        header("Location: login.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

// User Login
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if the user is the admin
    if ($email === 'admin@gmail.com' && $password === 'admin') {
        // Set admin session variable
        $_SESSION['admin_id'] = 1; // You can use any unique identifier for the admin
        header('Location: admin.php');
        exit();
    }

    // Fetch user data for regular users
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['name'] = $row['name'];
            $_SESSION['profile_picture'] = $row['profile_picture'];
            $_SESSION['cover_photo'] = $row['cover_photo'];
            header('Location: home.php');
            exit();
        } else {
            echo "Invalid Password";
        }
    } else {
        echo "User not found";
    }
    $stmt->close();
}

mysqli_close($conn);
?>