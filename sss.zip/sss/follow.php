<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    die(json_encode(['success' => false, 'message' => 'Unauthorized']));
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

$user_id = $_SESSION['user_id'];
$profile_user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;

if ($profile_user_id) {
    // Check if the user is already following
    $check_sql = "SELECT * FROM followers WHERE follower_id = '$user_id' AND following_id = '$profile_user_id'";
    $check_result = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($check_result) > 0) {
        // Unfollow
        $sql = "DELETE FROM followers WHERE follower_id = '$user_id' AND following_id = '$profile_user_id'";
    } else {
        // Follow
        $sql = "INSERT INTO followers (follower_id, following_id) VALUES ('$user_id', '$profile_user_id')";
    }
    mysqli_query($conn, $sql);

    // Get updated follower count
    $follower_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM followers WHERE following_id = '$profile_user_id'"));
    echo json_encode(['success' => true, 'followerCount' => $follower_count]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>