<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit();
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$data = json_decode(file_get_contents('php://input'), true);
$post_id = $data['post_id'];
$user_id = $_SESSION['user_id'];

// Check if the user has already liked the post
$check_like = mysqli_query($conn, "SELECT * FROM likes WHERE post_id = '$post_id' AND user_id = '$user_id'");
if (mysqli_num_rows($check_like) > 0) {
    // Unlike the post
    mysqli_query($conn, "DELETE FROM likes WHERE post_id = '$post_id' AND user_id = '$user_id'");
} else {
    // Like the post
    mysqli_query($conn, "INSERT INTO likes (post_id, user_id) VALUES ('$post_id', '$user_id')");
}

// Get the updated like count
$like_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS like_count FROM likes WHERE post_id = '$post_id'"))['like_count'];

echo json_encode(['success' => true, 'like_count' => $like_count]);
?>