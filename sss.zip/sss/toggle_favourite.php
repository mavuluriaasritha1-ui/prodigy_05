<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Not logged in']);
    exit();
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die(json_encode(['error' => 'Database connection failed']));
}

$data = json_decode(file_get_contents('php://input'), true);
$post_id = $data['post_id'];
$user_id = $_SESSION['user_id'];

// Check if already in favorites
$check = mysqli_query($conn, "SELECT * FROM favourites WHERE user_id='$user_id' AND post_id='$post_id'");
if (mysqli_num_rows($check) > 0) {
    // Remove from favorites
    mysqli_query($conn, "DELETE FROM favourites WHERE user_id='$user_id' AND post_id='$post_id'");
    echo json_encode(['status' => 'removed']);
} else {
    // Add to favorites
    mysqli_query($conn, "INSERT INTO favourites (user_id, post_id) VALUES ('$user_id', '$post_id')");
    echo json_encode(['status' => 'added']);
}

mysqli_close($conn);
?>
