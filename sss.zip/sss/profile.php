<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get the user_id from the URL
$profile_user_id = isset($_GET['user_id']) ? $_GET['user_id'] : $_SESSION['user_id'];

// Fetch Profile User Details
$profile_user_result = mysqli_query($conn, "SELECT * FROM users WHERE id='$profile_user_id'");
$profile_user = mysqli_fetch_assoc($profile_user_result);

// Fetch Posts of the Profile User
$post_result = mysqli_query($conn, "SELECT * FROM posts WHERE user_id='$profile_user_id' ORDER BY id DESC");

// Fetch Favourites (only if the logged-in user is viewing their own profile)
$fav_result = null;
if ($profile_user_id == $_SESSION['user_id']) {
    $fav_result = mysqli_query($conn, "
        SELECT posts.*, favourites.id AS fav_id FROM favourites 
        JOIN posts ON favourites.post_id = posts.id 
        WHERE favourites.user_id='$profile_user_id' ORDER BY posts.id DESC
    ");
}

// Handle post deletion
if (isset($_GET['delete_post'])) {
    $post_id = $_GET['delete_post'];

    // Delete related records in the likes table first
    mysqli_query($conn, "DELETE FROM likes WHERE post_id='$post_id'");

    // Now delete the post
    mysqli_query($conn, "DELETE FROM posts WHERE id='$post_id' AND user_id='$profile_user_id'");

    header('Location: profile.php?user_id=' . $profile_user_id); // Refresh the page
    exit();
}

// Function to highlight hashtags
function highlightHashtags($text) {
    return preg_replace('/#(\w+)/', '<span style="color: blue;">#$1</span>', $text);
}

// Handle favourite removal
if (isset($_GET['remove_favourite'])) {
    $fav_id = $_GET['remove_favourite'];
    mysqli_query($conn, "DELETE FROM favourites WHERE id='$fav_id' AND user_id='$profile_user_id'");
    header('Location: profile.php?user_id=' . $profile_user_id); // Refresh the page
    exit();
}

// Fetch follower and following counts
$follower_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM followers WHERE following_id = '$profile_user_id'"));
$following_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM followers WHERE follower_id = '$profile_user_id'"));

// Check if the logged-in user is following the profile user
$is_following = false;
if ($profile_user_id != $_SESSION['user_id']) {
    $check_follow_sql = "SELECT * FROM followers WHERE follower_id = '{$_SESSION['user_id']}' AND following_id = '$profile_user_id'";
    $check_follow_result = mysqli_query($conn, $check_follow_sql);
    if (mysqli_num_rows($check_follow_result) > 0) {
        $is_following = true;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body { background-color: #f5f5f5; }

        .profile-container { width: 100vw; height: 100vh; background: white; overflow: hidden; }

        .profile-header {
            width: 100%; height: 250px;
            background-image: url('<?php echo $profile_user['cover_photo']; ?>');
            background-size: cover; /* Ensures the image covers the container */
            background-position: center; /* Centers the image */
            position: relative;
        }

        .back-arrow {
            position: absolute; top: 15px; left: 15px;
            font-size: 24px; color: white; font-weight: bold;
            background: rgba(0, 0, 0, 0.6); padding: 8px 15px;
            border-radius: 50%; cursor: pointer;
            text-decoration: none;
        }

        .profile-picture {
            width: 120px; height: 120px; border-radius: 50%;
            border: 4px solid #fff; position: absolute; bottom: -60px; left: 20px;
            cursor: pointer;
        }

        .profile-info-container { display: flex; justify-content: space-between; align-items: center; padding: 20px; margin-top: 50px; }
        .profile-info h3 { font-size: 20px; margin-bottom: 5px; }
        .profile-info p { color: #555; font-size: 14px; margin-bottom: 10px; }
        .profile-buttons a { text-decoration: none; }

        .profile-buttons button {
            background-color:rgb(44, 42, 42); color:  #fff;
            padding: 10px 15px; border: none; border-radius: 20px;
            cursor: pointer; font-size: 14px;
            margin-left: 10px; /* Add spacing between buttons */
        }

        .tabs {
            display: flex; justify-content: center;
            border-top: 1px solid #e0e0e0;
        }

        .tabs div {
            flex: 1; text-align: center; padding: 15px 0;
            cursor: pointer; font-size: 16px; font-weight: bold;
        }

        .tabs div.active {
            border-bottom: 3px solid #007bff;
            color: #007bff;
        }

        .content { display: none; padding: 15px; }
        .content.active { display: block; }

        .grid-container {
            display: grid; grid-template-columns: repeat(3, 1fr);
            gap: 5px;
        }

        .grid-item {
            border: 1px solid #ddd; padding: 10px;
            background: white; border-radius: 10px;
            text-align: center;
            position: relative;
        }

        .grid-item img, .grid-item video {
            width: 100%; height: auto; max-height: 200px;
            object-fit: contain; border-radius: 10px;
        }

        .text-post {
            padding: 10px;
            background: #f9f9f9;
            border-radius: 10px;
            text-align: left;
        }

        .caption {
            margin-top: 10px;
            font-size: 14px;
            color: #333;
        }

        .no-posts, .no-favourites {
            text-align: center;
            font-size: 18px;
            color: #888;
            margin-top: 20px;
        }

        .three-dots {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 20px;
            cursor: pointer;
            z-index: 10;
        }

        .dropdown-menu {
            position: absolute;
            top: 30px;
            right: 10px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            display: none;
            z-index: 20;
        }

        .dropdown-menu button {
            display: block;
            width: 100%;
            padding: 10px;
            text-align: left;
            border: none;
            background: none;
            cursor: pointer;
            color: #333;
        }

        .dropdown-menu button:hover {
            background:rgb(213, 209, 209);
        }

        .popup-container {
            display: none; position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(0, 0, 0, 0.8);
            justify-content: center; align-items: center;
            z-index: 2000;
        }

        .popup {
            position: relative;
            background: white;
            padding: 20px;
            border-radius: 10px;
            width: 400px; /* Fixed size for all popups */
            max-height: 90vh;
            overflow-y: auto;
            text-align: center;
        }

        .popup img, .popup video {
            width: 100%; max-height: 70vh;
            border-radius: 10px; object-fit: contain;
        }

        .popup-caption {
            margin-top: 10px;
            font-size: 16px;
            color: #333;
        }

        .close-popup {
            position: absolute; top: -10px; right: -10px;
            font-size: 25px; color: white; cursor: pointer;
            font-weight: bold; background: rgba(0, 0, 0, 0.6);
            padding: 5px 10px; border-radius: 50%;
        }

        .followers-following {
            display: flex;
            gap: 20px;
            margin-top: 10px;
        }

        .followers-following span {
            cursor: pointer;
            color: #007bff;
        }

        .followers-following span:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="profile-container">
    <div class="profile-header">
        <a href="home.php" class="back-arrow">←</a>
        <img src="<?php echo $profile_user['profile_picture']; ?>" class="profile-picture" onclick="openProfilePopup()">
    </div>

    <div class="profile-info-container">
        <div class="profile-info">
            <h3><?php echo $profile_user['name']; ?></h3>
            <p>Joined: <?php echo date('F Y', strtotime($profile_user['created_at'])); ?></p>
            <div class="followers-following">
                <span onclick="openModal('followers')"><?php echo $follower_count; ?> Followers</span>
                <span onclick="openModal('following')"><?php echo $following_count; ?> Following</span>
            </div>
        </div>
        <div class="profile-buttons">
            <?php if ($profile_user_id == $_SESSION['user_id']): ?>
                <a href="edit_profile.php"><button>Edit Profile</button></a>
            <?php else: ?>
                <button id="followButton" onclick="toggleFollow(<?php echo $profile_user_id; ?>)">
                    <?php echo $is_following ? 'Unfollow' : 'Follow'; ?>
                </button>
                <a href="messages.php?user_id=<?php echo $profile_user_id; ?>"><button>Message</button></a>
            <?php endif; ?>
        </div>
    </div>

    <div class="tabs">
        <div class="active" onclick="showContent('posts')">Posts</div>
        <?php if ($profile_user_id == $_SESSION['user_id']): ?>
            <div onclick="showContent('favourites')">Favourites</div>
        <?php endif; ?>
    </div>

    <div class="content active" id="posts">
        <div class="grid-container">
            <?php if (mysqli_num_rows($post_result) > 0): ?>
                <?php while ($post = mysqli_fetch_assoc($post_result)): ?>
                    <div class="grid-item">
                        <?php if (!empty($post['post_image'])): ?>
                            <div onclick="openPost('<?php echo $post['post_image']; ?>', '<?php echo $post['post_text']; ?>')">
                                <?php if (strpos($post['post_image'], '.mp4') !== false): ?>
                                    <video><source src="<?php echo $post['post_image']; ?>" type="video/mp4"></video>
                                <?php else: ?>
                                    <img src="<?php echo $post['post_image']; ?>">
                                <?php endif; ?>
                            </div>
                            <?php if (!empty($post['post_text'])): ?>
                                <div class="caption"><?php echo highlightHashtags($post['post_text']); ?></div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="text-post">
                                <p><?php echo highlightHashtags($post['post_text']); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php if ($profile_user_id == $_SESSION['user_id']): ?>
                            <div class="three-dots" onclick="toggleDropdown(this)">&#8942;</div>
                            <div class="dropdown-menu">
                                <button onclick="deletePost(<?php echo $post['id']; ?>)">Delete Post</button>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="no-posts">No posts yet.</div>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($profile_user_id == $_SESSION['user_id']): ?>
        <div class="content" id="favourites">
            <div class="grid-container">
                <?php if (mysqli_num_rows($fav_result) > 0): ?>
                    <?php while ($fav = mysqli_fetch_assoc($fav_result)): ?>
                        <div class="grid-item">
                            <?php if (!empty($fav['post_image'])): ?>
                                <div onclick="openPost('<?php echo $fav['post_image']; ?>', '<?php echo $fav['post_text']; ?>')">
                                    <?php if (strpos($fav['post_image'], '.mp4') !== false): ?>
                                        <video><source src="<?php echo $fav['post_image']; ?>" type="video/mp4"></video>
                                    <?php else: ?>
                                        <img src="<?php echo $fav['post_image']; ?>">
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($fav['post_text'])): ?>
                                    <div class="caption"><?php echo highlightHashtags($fav['post_text']); ?></div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="text-post">
                                    <p><?php echo highlightHashtags($fav['post_text']); ?></p>
                                </div>
                            <?php endif; ?>
                            <div class="three-dots" onclick="toggleDropdown(this)">&#8942;</div>
                            <div class="dropdown-menu">
                                <button onclick="removeFavourite(<?php echo $fav['fav_id']; ?>)">Remove from Favourites</button>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="no-favourites">No favourites yet.</div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Followers/Following Modal -->
<div class="popup-container" id="followModal">
    <div class="popup">
        <span class="close-popup" onclick="closeModal()">&times;</span>
        <h2 id="modalTitle"></h2>
        <div id="modalContent"></div>
    </div>
</div>

<!-- Post Popup -->
<div class="popup-container" id="postPopup">
    <div class="popup">
        <span class="close-popup" onclick="closePostPopup()">&times;</span>
        <img id="popupImage" src="" alt="Post Image">
        <video id="popupVideo" controls style="display: none;">
            <source src="" type="video/mp4">
        </video>
        <div class="popup-caption" id="popupCaption"></div>
    </div>
</div>

<!-- Profile Picture Popup -->
<div class="popup-container" id="profilePopup">
    <div class="popup">
        <span class="close-popup" onclick="closeProfilePopup()">&times;</span>
        <img src="<?php echo $profile_user['profile_picture']; ?>" alt="Profile Picture" style="width: 100%; border-radius: 10px;">
    </div>
</div>

<script>
// Function to toggle follow/unfollow
function toggleFollow(userId) {
    fetch(`follow.php?user_id=${userId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const followButton = document.getElementById('followButton');
                followButton.innerText = followButton.innerText === 'Follow' ? 'Unfollow' : 'Follow';
                // Update follower count
                document.querySelector('.followers-following span:first-child').innerText = `${data.followerCount} Followers`;
            }
        });
}

// Function to open followers/following modal
function openModal(type) {
    fetch(`get_follow_data.php?user_id=<?php echo $profile_user_id; ?>&type=${type}`)
        .then(response => response.json())
        .then(data => {
            const modalTitle = document.getElementById('modalTitle');
            const modalContent = document.getElementById('modalContent');
            modalTitle.innerText = type === 'followers' ? 'Followers' : 'Following';
            modalContent.innerHTML = data.map(user => `
                <div style="display: flex; align-items: center; margin-bottom: 10px;">
                    <img src="${user.profile_picture}" style="width: 40px; height: 40px; border-radius: 50%; margin-right: 10px;">
                    <span>${user.name}</span>
                </div>
            `).join('');
            document.getElementById('followModal').style.display = 'flex';
        });
}

// Function to close modal
function closeModal() {
    document.getElementById('followModal').style.display = 'none';
}

// Function to open post popup
function openPost(imageSrc, caption) {
    const postPopup = document.getElementById('postPopup');
    const popupImage = document.getElementById('popupImage');
    const popupVideo = document.getElementById('popupVideo');
    const popupCaption = document.getElementById('popupCaption');

    if (imageSrc.includes('.mp4')) {
        popupVideo.style.display = 'block';
        popupImage.style.display = 'none';
        popupVideo.src = imageSrc;
    } else {
        popupImage.style.display = 'block';
        popupVideo.style.display = 'none';
        popupImage.src = imageSrc;
    }

    popupCaption.innerText = caption;
    postPopup.style.display = 'flex';
}

// Function to close post popup
function closePostPopup() {
    document.getElementById('postPopup').style.display = 'none';
}

// Function to open profile picture popup
function openProfilePopup() {
    document.getElementById('profilePopup').style.display = 'flex';
}

// Function to close profile picture popup
function closeProfilePopup() {
    document.getElementById('profilePopup').style.display = 'none';
}

// Function to switch between tabs
function showContent(tab) {
    document.querySelectorAll('.content').forEach(content => content.classList.remove('active'));
    document.querySelectorAll('.tabs div').forEach(tabDiv => tabDiv.classList.remove('active'));
    document.getElementById(tab).classList.add('active');
    document.querySelector(`.tabs div[onclick="showContent('${tab}')"]`).classList.add('active');
}

// Function to toggle dropdown menu
function toggleDropdown(element) {
    const dropdownMenu = element.nextElementSibling;
    dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
}

// Function to delete a post
function deletePost(postId) {
    if (confirm('Are you sure you want to delete this post?')) {
        window.location.href = `profile.php?user_id=<?php echo $profile_user_id; ?>&delete_post=${postId}`;
    }
}

// Function to remove a favourite
function removeFavourite(favId) {
    if (confirm('Are you sure you want to remove this from favourites?')) {
        window.location.href = `profile.php?user_id=<?php echo $profile_user_id; ?>&remove_favourite=${favId}`;
    }
}
</script>

</body>
</html>