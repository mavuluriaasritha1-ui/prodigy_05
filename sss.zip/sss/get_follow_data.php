<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    die(json_encode([]));
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die(json_encode([]));
}

$profile_user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;
$type = isset($_GET['type']) ? $_GET['type'] : null;

if ($profile_user_id && $type) {
    if ($type === 'followers') {
        $sql = "SELECT users.id, users.name, users.profile_picture FROM followers 
                JOIN users ON followers.follower_id = users.id 
                WHERE followers.following_id = '$profile_user_id'";
    } elseif ($type === 'following') {
        $sql = "SELECT users.id, users.name, users.profile_picture FROM followers 
                JOIN users ON followers.following_id = users.id 
                WHERE followers.follower_id = '$profile_user_id'";
    }
    $result = mysqli_query($conn, $sql);
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
    echo json_encode($data);
} else {
    echo json_encode([]);
}
?>