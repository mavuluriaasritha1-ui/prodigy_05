<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
    exit();
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit();
}

$post_id = $_POST['post_id'];
$user_id = $_SESSION['user_id'];
$action = $_POST['action'];

if ($action == 'add') {
    $stmt = $conn->prepare("INSERT INTO favourites (user_id, post_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $user_id, $post_id);
} else {
    $stmt = $conn->prepare("DELETE FROM favourites WHERE user_id = ? AND post_id = ?");
    $stmt->bind_param("ii", $user_id, $post_id);
}

if ($stmt->execute()) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Action failed']);
}

$stmt->close();
$conn->close();
?>
