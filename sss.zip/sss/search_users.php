<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    die("Unauthorized access");
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = $_GET['query'];
$sql = "SELECT id, name, profile_picture FROM users WHERE name LIKE '%$query%' LIMIT 5";
$result = mysqli_query($conn, $sql);

$users = [];
while ($row = mysqli_fetch_assoc($result)) {
    $users[] = $row;
}

echo json_encode($users);
?>