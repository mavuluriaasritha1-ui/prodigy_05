<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = new mysqli($host, $user, $password, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

// Fetch user details for profile picture
$user_query = "SELECT profile_picture, name FROM users WHERE id = '$user_id'";
$user_result = $conn->query($user_query);
$user_data = $user_result->fetch_assoc();
$profile_picture = $user_data['profile_picture'];
$user_name = $user_data['name'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $post_text = mysqli_real_escape_string($conn, $_POST['post_text']);
    $post_image = '';

    if (!empty($_FILES['post_image']['name'])) {
        $target_dir = "uploads/";
        $image_name = time() . '_' . basename($_FILES['post_image']['name']);
        $target_file = $target_dir . $image_name;
        
        if (move_uploaded_file($_FILES['post_image']['tmp_name'], $target_file)) {
            $post_image = $target_file;
        } else {
            echo "Error uploading image.";
        }
    }

    $sql = "INSERT INTO posts (user_id, post_text, post_image, created_at) 
            VALUES ('$user_id', '$post_text', '$post_image', NOW())";

    if ($conn->query($sql) === TRUE) {
        header("Location: home.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Post</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh; /* Ensure the body takes the full height of the viewport */
        }
        /* Header */
.header {
    position: fixed;
    top: 0;
    width: 100%;
    background-color: #fff;
    border-bottom: 1px solid #e0e0e0;
    padding: 15px 15px 15px 30px; /* Increased left padding */
    display: flex;
    align-items: center;
    z-index: 1000;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.header .back-arrow {
    font-size: 24px;
    cursor: pointer;
    color: #000;
    margin-left: 10px; /* Added margin to move the arrow slightly to the right */
}

.header .title {
    font-size: 22px;
    font-weight: bold;
    color: #000;
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
}
        /* Container */
        .container {
            width: 400px;
            background: rgba(255, 255, 255, 0.3);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            margin-top: 60px; /* Adjusted margin for header */
        }
        .profile {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .file-upload {
            margin-top: 10px;
        }
        textarea {
            width: 90%;
            height: 100px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            resize: none;
        }
        .preview-container {
            margin-top: 10px;
            display: none;
        }
        .preview-container img {
            max-width: 100%;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border: none;
            background-color: #007bff;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
    <script>
        function previewImage(event) {
            var preview = document.getElementById('imagePreview');
            var previewContainer = document.getElementById('previewContainer');

            if (event.target.files.length > 0) {
                var src = URL.createObjectURL(event.target.files[0]);
                preview.src = src;
                previewContainer.style.display = "block";
            } else {
                previewContainer.style.display = "none"; // Hide preview if no file selected
            }
        }
    </script>
</head>
<body>

<!-- Header -->
<div class="header">
    <i class="fas fa-arrow-left back-arrow" onclick="window.location.href='home.php'"></i>
    <div class="title">Create Post</div>
</div>

<!-- Container -->
<div class="container">
    <div class="profile">
        <img src="<?php echo $profile_picture; ?>" alt="Profile">
        <span><?php echo htmlspecialchars($user_name); ?></span>
    </div>
    <form method="post" action="create_post.php" enctype="multipart/form-data">
        <textarea name="post_text" placeholder="What's on your mind?" required></textarea>
        <input type="file" name="post_image" class="file-upload" accept="image/*" onchange="previewImage(event)">
        <div class="preview-container" id="previewContainer">
            <img id="imagePreview" src="" alt="Image Preview">
        </div>
        <button type="submit">Post</button>
    </form>
</div>

</body>
</html>