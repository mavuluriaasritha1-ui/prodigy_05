<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php'); // Redirect to admin login if not logged in
    exit();
}

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'sss';

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch Dashboard Metrics
$total_users = mysqli_query($conn, "SELECT COUNT(*) AS total_users FROM users")->fetch_assoc()['total_users'];
$total_posts = mysqli_query($conn, "SELECT COUNT(*) AS total_posts FROM posts")->fetch_assoc()['total_posts'];
$total_messages = mysqli_query($conn, "SELECT COUNT(*) AS total_messages FROM messages")->fetch_assoc()['total_messages'];

// Fetch User List
$user_list = mysqli_query($conn, "SELECT * FROM users");

// Fetch Post List
$post_list = mysqli_query($conn, "SELECT posts.*, users.name AS user_name FROM posts JOIN users ON posts.user_id = users.id");

// Fetch Favourites List
$favourites_list = mysqli_query($conn, "SELECT favourites.*, users.name AS user_name, posts.post_text AS post_content, posts.post_image 
                                       FROM favourites 
                                       JOIN users ON favourites.user_id = users.id 
                                       JOIN posts ON favourites.post_id = posts.id");

// Fetch Message List
$message_list = mysqli_query($conn, "
    SELECT messages.*, u1.name AS sender_name, u2.name AS recipient_name 
    FROM messages 
    JOIN conversations ON messages.conversation_id = conversations.id 
    JOIN users u1 ON messages.sender_id = u1.id 
    JOIN users u2 ON (conversations.user1_id = u2.id OR conversations.user2_id = u2.id) AND u2.id != messages.sender_id
");

// Handle Delete Actions via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $id = $_POST['delete_id'];
    $table = $_POST['table'];

    // Handle foreign key constraints for posts
    if ($table === 'posts') {
        // Delete related records in likes and favourites tables
        mysqli_query($conn, "DELETE FROM likes WHERE post_id = $id");
        mysqli_query($conn, "DELETE FROM favourites WHERE post_id = $id");
    }

    // Delete the record
    mysqli_query($conn, "DELETE FROM $table WHERE id = $id");
    exit(); // Stop further execution
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #f9f9f9;
        }

        /* Header */
        .header {
            position: fixed;
            top: 0;
            width: 100%;
            background-color: #fff;
            border-bottom: 1px solid #e0e0e0;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .header .logo {
            width: 40px;
            height: 40px;
        }

        .header .title {
            flex-grow: 1;
            text-align: center;
            font-size: 22px;
            font-weight: bold;
            color: #000;
        }

        .header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .header img:hover {
            transform: scale(1.1);
        }

        /* Admin Container */
        .admin-container {
            width: 90%;
            margin: 80px auto 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .admin-container h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #333;
        }

        .metrics {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .metric-card {
            background: #f0f0f0;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }

        .metric-card h3 {
            font-size: 18px;
            margin-bottom: 10px;
            color: #333;
        }

        .metric-card p {
            font-size: 24px;
            font-weight: bold;
            color: #007bff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }

        table th {
            background: #f0f0f0;
            font-weight: bold;
            color: #333;
        }

        table tr:hover {
            background: #f9f9f9;
        }

        .action-btn {
            padding: 6px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .action-btn.edit {
            background: #007bff;
            color: #fff;
        }

        .action-btn.delete {
            background: #dc3545;
            color: #fff;
        }

        .action-btn:hover {
            opacity: 0.8;
        }

        .media-preview {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<!-- Header -->
<div class="header">
    <img src="uploads/logo.jpg" class="logo">
    <div class="title">Admin Panel</div>
    <a href='login.php'>Logout</a>
</div>

<!-- Admin Container -->
<div class="admin-container">
    <!-- Dashboard -->
    <h2>Dashboard</h2>
    <div class="metrics">
        <div class="metric-card">
            <h3>Total Users</h3>
            <p><?php echo $total_users; ?></p>
        </div>
        <div class="metric-card">
            <h3>Total Posts</h3>
            <p><?php echo $total_posts; ?></p>
        </div>
        <div class="metric-card">
            <h3>Total Messages</h3>
            <p><?php echo $total_messages; ?></p>
        </div>
    </div>

    <!-- User Management -->
    <h2>User Management</h2>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Registration Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($user = mysqli_fetch_assoc($user_list)): ?>
            <tr id="user-<?php echo $user['id']; ?>">
                <td><?php echo $user['name']; ?></td>
                <td><?php echo $user['email']; ?></td>
                <td><?php echo $user['created_at']; ?></td>
                <td>
                    <button class="action-btn delete" onclick="deleteItem('users', <?php echo $user['id']; ?>)">Delete</button>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Post Management -->
    <h2>Post Management</h2>
    <table>
        <thead>
            <tr>
                <th>User</th>
                <th>Content</th>
                <th>Media</th>
                <th>Timestamp</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($post = mysqli_fetch_assoc($post_list)): ?>
            <tr id="post-<?php echo $post['id']; ?>">
                <td><?php echo $post['user_name']; ?></td>
                <td><?php echo substr($post['post_text'], 0, 50) . '...'; ?></td>
                <td>
                    <?php if (!empty($post['post_image'])): ?>
                        <?php if (strpos($post['post_image'], '.mp4') !== false): ?>
                            <video class="media-preview" src="<?php echo $post['post_image']; ?>"></video>
                        <?php else: ?>
                            <img class="media-preview" src="<?php echo $post['post_image']; ?>">
                        <?php endif; ?>
                    <?php else: ?>
                        <span>No Media</span>
                    <?php endif; ?>
                </td>
                <td><?php echo $post['created_at']; ?></td>
                <td>
                    <button class="action-btn delete" onclick="deleteItem('posts', <?php echo $post['id']; ?>)">Delete</button>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Favourites Management -->
    <h2>Favourites Management</h2>
    <table>
        <thead>
            <tr>
                <th>User</th>
                <th>Post Content</th>
                <th>Media</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($favourite = mysqli_fetch_assoc($favourites_list)): ?>
            <tr id="favourite-<?php echo $favourite['id']; ?>">
                <td><?php echo $favourite['user_name']; ?></td>
                <td><?php echo substr($favourite['post_content'], 0, 50) . '...'; ?></td>
                <td>
                    <?php if (!empty($favourite['post_image'])): ?>
                        <?php if (strpos($favourite['post_image'], '.mp4') !== false): ?>
                            <video class="media-preview" src="<?php echo $favourite['post_image']; ?>"></video>
                        <?php else: ?>
                            <img class="media-preview" src="<?php echo $favourite['post_image']; ?>">
                        <?php endif; ?>
                    <?php else: ?>
                        <span>No Media</span>
                    <?php endif; ?>
                </td>
                <td>
                    <button class="action-btn delete" onclick="deleteItem('favourites', <?php echo $favourite['id']; ?>)">Delete</button>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Message Management -->
    <h2>Message Management</h2>
    <table>
        <thead>
            <tr>
                <th>Sender</th>
                <th>Recipient</th>
                <th>Content</th>
                <th>Timestamp</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($message = mysqli_fetch_assoc($message_list)): ?>
            <tr id="message-<?php echo $message['id']; ?>">
                <td><?php echo $message['sender_name']; ?></td>
                <td><?php echo $message['recipient_name']; ?></td>
                <td><?php echo substr($message['message'], 0, 50) . '...'; ?></td>
                <td><?php echo $message['created_at']; ?></td>
                <td>
                    <button class="action-btn delete" onclick="deleteItem('messages', <?php echo $message['id']; ?>)">Delete</button>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script>
    function deleteItem(table, id) {
        if (confirm("Are you sure you want to delete this item?")) {
            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `delete_id=${id}&table=${table}`,
            })
            .then(response => {
                if (response.ok) {
                    // Remove the deleted row from the table
                    const row = document.getElementById(`${table}-${id}`);
                    if (row) {
                        row.remove();
                    } else {
                        console.error("Row not found");
                    }
                } else {
                    console.error("Failed to delete the item");
                    alert("Failed to delete the item.");
                }
            })
            .catch(error => {
                console.error("Error:", error);
            });
        }
    }
</script>

</body>
</html>